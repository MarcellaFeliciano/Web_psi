
all = [
    'books',
    'users',
    'emprestimos'
]